<?php
session_start(); // Starte die PHP-Sitzung

// Datenbankverbindung herstellen
$database_host = "database"; // Name des MySQL-Containers
$database_user = "root"; // Benutzername für die MySQL-Datenbank
$database_password = $_ENV['MYSQL_ROOT_PASSWORD']; // Passwort für die MySQL-Datenbank
$database_name = "Test"; // Name der MySQL-Datenbank
$port = 3306; // Port für die MySQL-Verbindung

$link = mysqli_connect($database_host, $database_user, $database_password, $database_name, $port);

// Überprüfe die Verbindung
if (!$link) {
    die("Verbindung zur MySQL-Datenbank fehlgeschlagen: " . mysqli_connect_error());
}

// Überprüfe, ob der Benutzer bereits angemeldet ist
if(isset($_SESSION['username'])) {
    echo "ello"; // Weiterleiten, wenn der Benutzer bereits angemeldet ist
    exit();
}

// Überprüfe, ob das Formular abgeschickt wurde
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Benutzername und Passwort aus dem Formular erhalten
    $input_username = $_POST['name'];
    $input_password = $_POST['passwort'];

    // Überprüfen, ob Benutzername und Passwort korrekt sind
    $sql = "SELECT * FROM user WHERE name='$input_username' AND passwort='$input_password'";
    $result = mysqli_query($link, $sql);

    if (mysqli_num_rows($result) > 0) {
        // Anmeldung erfolgreich, speichere den Benutzernamen in der Sitzung
        $_SESSION['username'] = $input_username;
        echo "geile sache"; // Weiterleiten zur Dashboard-Seite
        exit();
    } else {
        $login_error = "Ungültiger Benutzername oder Passwort.";
    }
}

mysqli_close($link);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <?php
    // Fehlermeldung anzeigen, wenn Anmeldung fehlgeschlagen ist
    if (isset($login_error)) {
        echo "<p>$login_error</p>";
    }
    ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Benutzername:</label><br>
        <input type="text" id="name" name="name"><br>
        <label for="passwort">Passwort:</label><br>
        <input type="passwort" id="passwort" name="passwort"><br><br>
        <input type="submit" name="sub" value="Anmelden">
    </form>
</body>
</html>
