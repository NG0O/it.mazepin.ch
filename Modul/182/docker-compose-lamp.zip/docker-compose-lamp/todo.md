# ToDo List 

* Redesign readme.md for better readability
* Update issue templates
