<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\MyMail;
use Illuminate\Support\Facades\Log;

class MailController extends Controller
{
    public function showForm()
    {
        return view('send-mail');
    }

    public function sendMail(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'subject' => 'required|string',
            'message' => 'required|string',
        ]);

        $details = [
            'email' => $request->email,
            'subject' => $request->subject,
            'message' => $request->message,
        ];

        try {
            Mail::to($details['email'])->send(new MyMail($details));
            Log::info('Mail sent successfully to ' . $details['email']);
            return back()->with('status', 'Email sent successfully!');
        } catch (\Exception $e) {
            Log::error('Failed to send mail: ' . $e->getMessage());
            return back()->with('status', 'Failed to send email.');
        }
    }
}
