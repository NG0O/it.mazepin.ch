<?php echo e($slot); ?>

<?php /**PATH /Users/noah/Documents/CODE/Laravel/myWebsite/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>