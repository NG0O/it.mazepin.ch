<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="/icon.ico">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

    <!-- Custom CSS for Dark Mode -->
    <style>
        body.dark-mode {
            background-color: #121212;
            color: #ffffff;
        }
        .navbar.dark-mode {
            background-color: #1f1f1f;
        }
        .card.dark-mode {
            background-color: #1e1e1e;
            color: #ffffff;
        }
        .table-dark-mode {
            background-color: #2c2c2c;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand d-flex" href="<?php echo e(route('home')); ?>">
                    <div><img src="/icon.ico"  style="height: 50px;" class="p-2"></div> 
                    <div class="pl-3 pt-3"><?php echo e(config('app.name', 'Laravel')); ?></div>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Dark Mode Toggle -->
                        <li class="nav-item d-flex align-items-center">
                            <span class="me-2">Dark Mode</span>
                            <label class="switch">
                                <input type="checkbox" id="dark-mode-toggle">
                                <span class="slider round"></span>
                            </label>
                        </li>

                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('account')); ?>">
                                        <?php echo e(__('Account')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Dark Mode Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const darkModeToggle = document.getElementById('dark-mode-toggle');
            const body = document.body;
            const navbar = document.querySelector('.navbar');
            const cards = document.querySelectorAll('.card');
            const tables = document.querySelectorAll('.table');

            // Load the mode from local storage
            if (localStorage.getItem('dark-mode') === 'enabled') {
                darkModeToggle.checked = true;
                body.classList.add('dark-mode');
                navbar.classList.add('dark-mode');
                cards.forEach(card => card.classList.add('dark-mode'));
                tables.forEach(table => table.classList.add('table-dark-mode'));
            }

            darkModeToggle.addEventListener('change', function (e) {
                if (darkModeToggle.checked) {
                    body.classList.add('dark-mode');
                    navbar.classList.add('dark-mode');
                    cards.forEach(card => card.classList.add('dark-mode'));
                    tables.forEach(table => table.classList.add('table-dark-mode'));
                    localStorage.setItem('dark-mode', 'enabled');
                } else {
                    body.classList.remove('dark-mode');
                    navbar.classList.remove('dark-mode');
                    cards.forEach(card => card.classList.remove('dark-mode'));
                    tables.forEach(table => table.classList.remove('table-dark-mode'));
                    localStorage.removeItem('dark-mode');
                }
            });
        });
    </script>

    <!-- Toggle Switch CSS -->
    <style>
        .switch {
            position: relative;
            display: inline-block;
            width: 34px;
            height: 20px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 14px;
            width: 14px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: #2196F3;
        }

        input:checked + .slider:before {
            transform: translateX(14px);
        }
    </style>
</body>
</html>
<?php /**PATH /Users/noah/Documents/CODE/Laravel/myWebsite/resources/views/layouts/app.blade.php ENDPATH**/ ?>