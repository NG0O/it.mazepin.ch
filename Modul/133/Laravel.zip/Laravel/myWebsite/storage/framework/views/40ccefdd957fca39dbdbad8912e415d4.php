<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Centered Link to Mail Page -->
                    <div class="text-center mb-3">
                        <a href="<?php echo e(route('send.mail.form')); ?>" class="btn btn-primary">Send Mail</a>
                    </div>

                    <h1 class="mt-4">Customer List</h1>
                    <table class="table table-striped mt-2">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($customer->name); ?></td>
                                    <td><?php echo e($customer->address); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('customers.edit', $customer->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <!-- Button to Add New Customer -->
                    <div class="text-center mt-3">
                        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-success">Add New Customer</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/noah/Documents/CODE/Laravel/myWebsite/resources/views/home.blade.php ENDPATH**/ ?>