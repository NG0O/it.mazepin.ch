<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/noah/Documents/CODE/Laravel/myWebsite/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>