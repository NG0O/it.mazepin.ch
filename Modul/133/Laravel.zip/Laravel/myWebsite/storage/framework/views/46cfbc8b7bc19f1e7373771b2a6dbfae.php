<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(config('app.name')); ?></title>
</head>
<body>
    <h1><?php echo e($details['subject']); ?></h1>
    <p><?php echo e($details['message']); ?></p>
</body>
</html>
<?php /**PATH /Users/noah/Documents/CODE/Laravel/myWebsite/resources/views/emails/my-mail.blade.php ENDPATH**/ ?>