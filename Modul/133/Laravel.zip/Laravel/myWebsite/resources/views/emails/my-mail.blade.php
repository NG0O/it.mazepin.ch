<!DOCTYPE html>
<html>
<head>
    <title>{{ config('app.name') }}</title>
</head>
<body>
    <h1>{{ $details['subject'] }}</h1>
    <p>{{ $details['message'] }}</p>
</body>
</html>
