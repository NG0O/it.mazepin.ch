@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <!-- Centered Link to Mail Page -->
                    <div class="text-center mb-3">
                        <a href="{{ route('send.mail.form') }}" class="btn btn-primary">Send Mail</a>
                    </div>

                    <h1 class="mt-4">Customer List</h1>
                    <table class="table table-striped mt-2">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($customers as $customer)
                                <tr>
                                    <td>{{ $customer->name }}</td>
                                    <td>{{ $customer->address }}</td>
                                    <td>
                                        <a href="{{ route('customers.edit', $customer->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <!-- Button to Add New Customer -->
                    <div class="text-center mt-3">
                        <a href="{{ route('customers.create') }}" class="btn btn-success">Add New Customer</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
