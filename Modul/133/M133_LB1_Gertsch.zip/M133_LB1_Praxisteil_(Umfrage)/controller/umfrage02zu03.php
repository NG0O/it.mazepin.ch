<?php 
session_start();

// Save form data in the session
if (isset($_POST['geburtsdatum']) && isset($_POST['wohnort']) && isset($_POST['beruf'])) {
    $_SESSION['geburtsdatum'] = $_POST['geburtsdatum'];
    $_SESSION['wohnort'] = $_POST['wohnort'];
    $_SESSION['beruf'] = $_POST['beruf'];
}

// No need to ensure directory exists since we're saving in the root directory
$directorypfad = "../model/"; // Root directory

// Get the user email from the session and prepare data
$benutzer = isset($_SESSION['benutzer']) ? $_SESSION['benutzer'] : "initial";
$data = $benutzer . "\n" . $_SESSION['geburtsdatum'] . "\n" . $_SESSION['wohnort'] . "\n" . $_SESSION['beruf'];

// Save data to file in the root directory
$filename = $directorypfad . "user_" . $benutzer . ".data";
if (file_put_contents($filename, $data) === false) {
    die("Error: Unable to save data to file.");
}

// Redirect to the next page
header("Location: ../view/umfrage03.php");
exit();
?>
