<?php
    session_start(); // Start the session
    session_destroy(); // Destroy the session
    header("Location: ../view/umfrage01.php"); // Redirect to umfrage01.php
    exit(); // Ensure no further code is executed after the redirect
?>