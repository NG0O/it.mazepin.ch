<?php 
  session_start();
  
  // Ensure the request method is POST and the form fields are set
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['benutzer']) && isset($_POST['password'])) {
      $_SESSION['benutzer'] = $_POST['benutzer'];
      $_SESSION['password'] = $_POST['password'];

      // Check input content
      if ((strlen($_POST['benutzer']) > 0) && (strlen($_POST['password']) > 0)) {
          // Redirect
          header("Location: ../view/umfrage02.php");
          exit();
      } else {
          $html_Output = '<html><head>';
          $html_Output .= '<title>Anmeldung</title>';
          $html_Output .= '<link rel="stylesheet" href="../model/style.css">';
          $html_Output .= '</head><body>';
          $html_Output .= '<h1>Uups</h1>';
          $html_Output .= 'Das war nicht erfolgreich';
          $html_Output .= '<br><a href="../view/umfrage01.php"> < zurück </a>';
          $html_Output .= '</body></html>';
          echo $html_Output;
      }
    } else {
      // If the form fields are not set
      $html_Output = '<html><head>';
      $html_Output .= '<title>Anmeldung</title>';
      $html_Output .= '<link rel="stylesheet" href="../model/style.css">';
      $html_Output .= '</head><body>';
      $html_Output .= '<h1>Uups</h1>';
      $html_Output .= 'Das war nicht erfolgreich';
      $html_Output .= '<br><a href="../view/umfrage01.php"> < zurück </a>';
      $html_Output .= '</body></html>';
      echo $html_Output;
    }
  }
?>
