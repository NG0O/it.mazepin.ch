<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="UTF-8">
    <title>Umfrage | 2</title> 
    <link rel="stylesheet" href="../model/style.css">
  </head>
  <body>
    <span class="button" id="toggle-login">M133</span>
    <div id="formular">
      <div id="triangle"></div>
      <h1>
        <img class="umfragebild" src="../model/umfrage.jpg" alt="Umfrage Bild">
        Umfrage (2/3)
      </h1>
      <form action="../controller/umfrage02zu03.php" method="post">
        <label for="geburtsdatum">Geburtsdatum:</label>
        <input type="text" id="geburtsdatum" name="geburtsdatum" placeholder="TT.MM.JJJJ" required="required"/>
        <label for="wohnort">Wohnort:</label>
        <input type="text" id="wohnort" name="wohnort" placeholder="9999 Musterlingen" required="required"/>
        <label for="beruf">Beruf:</label>
        <input type="text" id="beruf" name="beruf" placeholder="Informatiker EFZ" required="required"/>
        <input type="submit" value="weiter >" />
      </form>
    </div>
    <script src="../index.js"></script>         
  </body>
</html>

