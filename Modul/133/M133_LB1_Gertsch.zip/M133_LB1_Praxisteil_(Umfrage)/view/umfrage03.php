<?php
	session_start();
	
	// Get values from session
	$benutzer = isset($_SESSION['benutzer']) ? $_SESSION['benutzer'] : " // hier EMail einsetzen "; 
	$gebdat = isset($_SESSION['geburtsdatum']) ? $_SESSION['geburtsdatum'] : " // Geburtsdatum einsetzen ";
	$ort = isset($_SESSION['wohnort']) ? $_SESSION['wohnort'] : " // hier Wohnort einsetzen ";
	$beruf = isset($_SESSION['beruf']) ? $_SESSION['beruf'] : " // hier Beruf einsetzen ";
	
	// Assign initial value if $benutzer is not filled
	if (strlen($benutzer) < 2) {
	    $benutzer = "initial";
	}
	$data = $benutzer."\n".$gebdat."\n".$ort."\n".$beruf;

	// Save data to file
	$directorypfad = "";
	$filename = $directorypfad."user_".$benutzer.".data";
	file_put_contents($filename, $data);
?>
<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="UTF-8">
    <title>Umfrage | 3</title> 
    <link rel="stylesheet" href="../model/style.css">
  </head>

  <body>
    <span class="button" id="toggle-login">M133</span>
	<div id="formular">
	  <div id="triangle"></div>
	  <h1>
	  	<img class="umfragebild" src="../model/umfrage.jpg" alt="Umfrage Bild">
	  	Umfrage (3/3)
	  </h1>
	  <form action="../controller/zurueck-zum-start.php">
		  <div>
		  	<h2>Zusammenfassung</h2>
		  	<br>
		  	<table>
		  		<tr valign="top">
		  			<td>Name (EMail):</td><td class="wert"><?= htmlspecialchars($benutzer) ?></td>
		  		</tr>
		  		<tr valign="top">
		  			<td>Geburtsdatum:</td><td class="wert"><?= htmlspecialchars($gebdat) ?></td>
		  		</tr>
		  		<tr valign="top">
		  			<td>Wohnort:</td><td class="wert"><?= htmlspecialchars($ort) ?></td>
		  		</tr>
		  		<tr valign="top">
		  			<td>Beruf:</td><td class="wert"><?= htmlspecialchars($beruf) ?></td>
		  		</tr>
		  	</table>
		  </div>
	    <input type="submit" value="< zurück zum Start" />
	  </form>
	</div>
    <script src="../index.js"></script>         
  </body>
</html>
