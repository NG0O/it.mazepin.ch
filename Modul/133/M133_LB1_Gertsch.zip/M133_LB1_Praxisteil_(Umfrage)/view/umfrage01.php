<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="UTF-8">
    <title>Umfrage | 1</title> 
    <link rel="stylesheet" href=" ../model/style.css">
  </head>
  <body>
    <span class="button" id="toggle-login">M133</span>
    <div id="formular">
      <div id="triangle"></div>
      <h1>
        <img class="umfragebild" src=" ../model/umfrage.jpg" alt="Umfrage Bild">
        Umfrage (1/3)
      </h1>
      <form action="../controller/umfrage01zu02.php" method="post">
        <label for="email">E-Mail:</label>
        <input type="email" id="email" name="benutzer" placeholder="E-Mail" required="required"/>
        <label for="password">Passwort:</label>
        <input type="password" id="password" name="password" placeholder="Password" required="required"/>
        <input type="submit" value="weiter >" />
      </form>
    </div>
    <script src="../index.js"></script>         
  </body>
</html>
